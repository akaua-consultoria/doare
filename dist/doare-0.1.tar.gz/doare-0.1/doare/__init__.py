# -*- coding: utf-8 -*-
"""
Created on Wed Sep 20 09:34:49 2023

@author: nfama
"""

from .get_data import get_data